//Write a C++ program for thick line generation using Bresenham’s Algorithms.

 #include<graphics.h>
 #include<iostream>
 #include<stdlib.h>
 #include<math.h>

 using namespace std;

 void generate_line(int,int,int,int);


 int main()
 {
   
  int gd=DETECT,gm=VGAMAX;
  int  x1,y1,x2,y2,y3,y4,y5,y6,dx,dy;
  long temp,temp1,temp2,w,wy;
  
  initgraph(&gd,&gm,NULL);

  cout<<"\n Enter Co-ordinates:  "; 
  cin >> x1 >> y1 >> x2 >> y2;

  cout<<"\n Enter thickness "; 
  cin >> w;
 
  dx = abs(x2 - x1);
  dy = abs(y2 - y1);
  
  temp1 = dx*dx;
  temp2 = dy*dy;

  temp = temp1+temp2;
  wy = ( ((w-1)/2)* ((sqrt(temp))/dx) );
  cout << "wy" << wy;
  generate_line(x1,y1,x2,y2);

  y3=y1+wy;
  y4=y2+wy;
  y5=y1-wy;
  y6=y2-wy;
      
  do {
      generate_line(x1,y3,x2,y4);
      generate_line(x1,y5,x2,y6);
      y3--;
      y4--;
      y5++;
      y6++; 
     }while(y3>y1);

  getch();
  return 0;
 }

 
 void generate_line(int x1, int y1, int x2, int y2)
 {
  float  g,dx,dy,w,wy,t1,t2;
  
  if(x1 > x2 || y1 > y2)
   {
      t1 = x2;
      x2 = x1;
      x1 = t1;
      t2 = y2;
      y2 = y1;
      y1 = t2;
   }

   dx = abs(x2 - x1);
   dy = abs(y2 - y1);
   g = 2*dy-dx;

   while( x1 <= x2 )
   {
   
    if( g >= 0)
    {
        x1 = x1 + 1;
        y1 = y1 + 1;
        g = g + 2*dy - 2*dx;
        putpixel(x1,y1,WHITE);
    }
    else
    {
        x1 = x1 + 1;
         g = g + 2*dy;
        putpixel(x1,y1,WHITE);
    } 
   }  

 }
