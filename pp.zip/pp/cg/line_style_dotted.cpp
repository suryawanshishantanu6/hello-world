//Write a C++ program for dotted line generation using Bresenham’s Algorithms.

#include<graphics.h>
#include<iostream>
#include<stdlib.h>
#include<math.h>

 using namespace std;

 int main()
  {
   
   int gd=DETECT,gm=VGAMAX;
   int  x1,y1,x2,y2,dx,dy,g,t1,t2,i=0;

   initgraph(&gd,&gm,NULL);

   cout<<"\n Enter Co-ordinates:  "; 
   cin >> x1 >> y1 >> x2 >> y2;
    if(x1 > x2 || y1 > y2)
      {
            t1 = x2;
            x2 = x1;
            x1 = t1;
            t2 = y2;
            y2 = y1;
            y1 = t2;
      }

   dx = abs(x2 - x1);
   dy = abs(y2 - y1);
   g = 2*dy-dx;

   while( x1 <= x2 )
   {
    i++;
    if( g >= 0)
    {
        x1 = x1 + 1;
        y1 = y1 + 1;
        g = g + 2*dy - 2*dx;
        if(i%2==0) { putpixel(x1,y1,WHITE); }
    }
    else
    {
        x1 = x1 + 1;
        g = g + 2*dy;
        if(i%2==0) { putpixel(x1,y1,WHITE); }
    }   
  }

  getch();
  return 0;
 }

