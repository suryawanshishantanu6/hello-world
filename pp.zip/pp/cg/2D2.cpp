 //2-D rotate object about arbitrary point given by user.

 #include<graphics.h>
 #include<iostream>
 #include<stdlib.h>
 #include<math.h>

 using namespace std;

 int main()
  {
            int gm, gd=DETECT;
            int x1,x2,x3,y1,y2,y3,c;
            int xt,yt,r;
            float t,sx,sy,nx1,nx2,nx3,ny1,ny2,ny3;
            char ans;
            initgraph(&gd,&gm,NULL);
            cout << " \t Program for basic transactions\n";
            cout << " \n\t Enter the points of line:  ";
            
            cin >> x1 >> y1 >> x2 >> y2;
            line(x1,y1,x2,y2);
            cout <<  "\nEnter the arbitary point: ";
            cin >> xt >> yt;
            x1=x1-xt;
            y1=y1-yt;
            x2=x2-xt;
            y2=y2-yt;
            setcolor(1);
            line(x1,y1,x2,y2);
                                    
            cout << " \n Enter the angle of rotation: ";
            cin >> r;
            t=3.14*r/180;
            x1=abs(x1*cos(t)-y1*sin(t));
            y1=abs(x1*sin(t)+y1*cos(t));
            x2=abs(x2*cos(t)-y2*sin(t));
            y2=abs(x2*sin(t)+y2*cos(t));
            setcolor(4);
            line(x1,y1,x2,y2);
                                                  
            x1=x1+xt;
            y1=y1+yt;
            x2=x2+xt;
            y2=y2+yt;
            setcolor(14);
            line(x1,y1,x2,y2);
               
            getch();
            return 0;
       }

/* OUTPUT:

 Program for basic transactions 
	 Enter the points of line
300 300 400 400

Enter the arbitary point: 200 200
 
 Enter the angle of rotation: 30
*/
