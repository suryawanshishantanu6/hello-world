//Write a C++ program for line generation using DDA Algorithm.

#include<graphics.h>
#include<iostream>
#include<stdlib.h>
#include<math.h>

 using namespace std;

 int main()
  {
   
   int gd=DETECT,gm=VGAMAX;
   float  x1,y1,x2,y2,dx,dy,m,xr,yr,t1,t2;

   initgraph(&gd,&gm,NULL);

   cout<<"\n Enter Co-ordinates:  "; 
   cin >> x1 >> y1 >> x2 >> y2;

   if(x1 > x2 || y1 > y2)
      {
            t1 = x2;
            x2 = x1;
            x1 = t1;
            t2 = y2;
            y2 = y1;
            y1 = t2;
      }

   dx = abs(x2 - x1);
   dy = abs(y2 - y1);
   m = dy/dx;

   while( x1 <= x2 )
   {
   
    if( dx > dy)
    {
        x1 = x1 + 1;
        y1 = y1 + m;
        yr=round(y1);
        putpixel(x1,yr,WHITE);
    }
    else
    {
        y1 = y1 + 1;
        x1 = x1 + (1/m);
        xr = round(x1);
        putpixel(xr,y1,WHITE);
    }   
}

   getch();
   return 0;
  }

