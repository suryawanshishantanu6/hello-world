//Write a C++ for to draw the given pattern using any Line drawing algorithms.

 #include<graphics.h>
 #include<iostream>
 #include<stdlib.h>
 #include<math.h>

 using namespace std;
 
 void line_draw(int,int,int,int);

 int main()
  {
   
   int gd=DETECT,gm=VGAMAX;
   int  x1,y1,x2,y2;

   initgraph(&gd,&gm,NULL);

   line_draw(100,100,400,100);
   line_draw(400,100,400,300);
   line_draw(400,300,100,300);
   line_draw(100,300,100,100);

   line(250,100,400,200);
   line(400,200,250,300);
   line(250,300,100,200);
   line(100,200,250,100);
   
   line_draw(175,150,325,150);
   line_draw(325,150,325,250);
   line_draw(325,250,175,250);
   line_draw(175,250,175,150);
   
   getch();
   return 0;
  }

 void line_draw(int x1,int y1,int x2,int y2)
  { 
    float  dx,dy,m,xr,yr,x,y,t1,t2,i=0;

    dx = abs(x2 - x1);
    dy = abs(y2 - y1);
    m = dy/dx;

    if(x1 > x2 || y1 > y2)
      {
            t1 = x2;
            x2 = x1;
            x1 = t1;
            t2 = y2;
            y2 = y1;
            y1 = t2;
      }

    if( dx >= dy)
    {
        
    x=x1;
    y=y1;
      while (i<=dx)
       {
        i++;
        x = x + 1;
        y = y + m;
        yr=round(y);
        putpixel(x,yr,WHITE);
       }
     } 
    else
    {
      
    x=x1;
    y=y1;
     while (i<=dy)
      {
        i++;
   
        y = y + 1;
        x = x + (1/m);
        xr = round(x);
        putpixel(xr,y,WHITE);
      }   
    }
   }


