// Write C++ program to implement reflection of2-D object about X axis, Y axis and about X=Y axis.

 #include<graphics.h>
 #include<iostream>
 #include<stdlib.h>
 #include<math.h>

 using namespace std;
  int main()
   {
     int gd=DETECT,gm;
     int xmid,ymid,x1,y1,x2,y2,x3,y3,temp,option,a1,a2,a3,b1,b2,b3;
     char ans;
     initgraph(&gd,&gm,NULL);

     cout <<  "Enter first co-ords of the triangle\n";
     cin  >> a1 >> b1;
     cout <<  "Enter second co-ords of the triangle\n";
     cin  >> a2 >> b2;
     cout <<  "Enter third co-ords of the triangle\n";
     cin  >> a3 >> b3;

     xmid= getmaxx()/2;
     ymid= getmaxy()/2;
     
     line(5,ymid,getmaxx()-5,ymid);
     line(xmid+3,5,xmid+3,getmaxy()-5);

     //Triangle in 1st quadrant
     line(a1+xmid,ymid-b1,a2+xmid,ymid-b2);
     line(a2+xmid,ymid-b2,a3+xmid,ymid-b3);
     line(a3+xmid,ymid-b3,a1+xmid,ymid-b1);

     do
      {
        x1=a1; x2=a2; x3=a3; y1=b1; y2=b2; y3=b3;
        cout <<  "Reflection about \n";
        cout <<  "X axis :  1\n";
        cout <<  "Y axis : 2\n";
        cout <<  "X=Y axis : 3\n";
        cout <<  " Enter the option (1-3):";
        cin  >> option;

        switch( option)
         {
           case 1:  y1=-y1; y2=-y2;y3=-y3; 
                    line(x1+xmid,ymid-y1,x2+xmid,ymid-y2);
                    line(x2+xmid,ymid-y2,x3+xmid,ymid-y3);
                    line(x3+xmid,ymid-y3,x1+xmid,ymid-y1);
                    break;
                    
           case 2:  x1=-x1;x2=-x2;x3=-x3;
                    line(x1+xmid,ymid-y1,x2+xmid,ymid-y2);
                    line(x2+xmid,ymid-y2,x3+xmid,ymid-y3);
                    line(x3+xmid,ymid-y3,x1+xmid,ymid-y1);
                    break;

           case 3:  temp=x1;    x1=y1;     y1=temp;
                    temp=x2;    x2=y2;     y2=temp;
                    temp=x3;    x3=y3;     y3=temp;
                    line(x1+xmid,ymid-y1,x2+xmid,ymid-y2);
                    line(x2+xmid,ymid-y2,x3+xmid,ymid-y3);
                    line(x3+xmid,ymid-y3,x1+xmid,ymid-y1);
   
                
         }
        cout << "Enter 'y' to continue....";
        cin >> ans;
       }while(ans=='y' || ans=='Y');
    exit(0);   
    getch();
    return 0;
  } 
