//Write a C++ program for a Circle drawing using Bresenham’s Algorithms.

 #include<graphics.h>
 #include<iostream>
 #include<stdlib.h>
 #include<math.h>

 using namespace std;

  void display(int,int,int);

  int main()
  {
   
   int gd=DETECT,gm=VGAMAX;
   int  x,y,r;

   initgraph(&gd,&gm,NULL);

   cout<<"\n Enter center point of the circle : "; 
   cin >> x >> y;

   cout<<"\n Enter radius of the circle : "; 
   cin >> r;

   display(x,y,r);
  
   getch();
   return 0;
 }

  void display(int x1, int y1, int r) //Bresenham's Circle
    {
      int i, x, y;
      float d;
      x=0, y=r;
      d = 3 - 2*r; //decision variable

      do
       {
        putpixel(x1+x, y1+y,15);
        putpixel(x1+y, y1+x,15);
        putpixel(x1+y, y1-x,15);
        putpixel(x1+x, y1-y,15);
        putpixel(x1-x, y1-y,15);
        putpixel(x1-y, y1-x,15);
        putpixel(x1-y, y1+x,15);
        putpixel(x1-x, y1+y,15);

        if(d<=0)
         {
          x = x + 1;
	  d = d + (4*x) + 6;
	 }
	else
	 {
	  x = x + 1;
	  y = y - 1;
	  d = d + (4*x-4*y) + 10;
	 }

     }while(x<=y);
    }

