//implementation of dictionary
//assignment-4
//prajjkta patil
//rollno 51
//se-B
#include<string.h>		
#include<stdio.h>			
#include<iostream>		
using namespace std;

//CLASS FOR NODE
class node				
{
     public:
     node *left,*right;
     char word[50];
     char meaning[50];
};
//CLASS FOR DICTIONARY
class dict					
{
     public:
     node *root;
     dict()
     {
          root=NULL;
     }     
     void create();
     void insert();
     node* search(char key[50]);
     void inorder(node *);
     void descend(node *);
     void update();
     void deletew();
   
};

//FUNCTION TO CREATE A DICTIONARY
void dict :: create()			
{
     root=new node;
     cout<<"enter the word\n";
     cin>>root->word;
     cout<<"enter the meaning\n";
     cin>>root->meaning;
     root->left=NULL;
     root->right=NULL;
}

//FUNCTION TO INSERT A WORD
void dict :: insert()				
{
     char x[50];
     char y[50];
     node *p,*q;
     if(root==NULL)
     {
          create();
          return;
     }
     p=new node;
     cout<<"enter the word\n";
     cin>>x;   
     cout<<"enter the meaning\n";
     cin>>y;
     strcpy(p->word,x);
     strcpy(p->meaning,y);
     
     p->left=NULL;
     p->right=NULL;
     q=root;
     while(q!=NULL)
     {
          if(p->word<q->word)
          {
          	if(q->left==NULL)
          	{
          		q->left=p;
          		return;
          	}
          	else
          		q=q->left;        
        	 }
         
          else 
          {
              if(q->right==NULL)
              	{
              		q->right=p;
              		return;
              	} 
              	else
          	{
              		q=q->right;
         		 }
          }
          
      }
}

//FUNCTION TO SEARCH A WORD
node* dict :: search(char key[50])			
{
     node *temp;
     int cnt=0;
     temp=root;
     if(temp==NULL)
		cout<<"dictionary is empty";
     while(temp!=NULL)
     {
          if(strcmp(temp->word,key)==0)
          {
          	  cout<<"key found";
        	  return temp ;
          }
          else if(strcmp(key,temp->word)==-1)	          
	            temp=temp->left;     	     
     	     else    	     
     	          temp=temp->right;     	            	              	              
          
      }             
               
}

//FUNCTION FOR INORDER TRAVERSAL
void dict :: inorder(node *root)				
{
	
	if(root!=NULL)
	{
		inorder(root->left);
		cout<<root->word;
		cout<<root->meaning;
		inorder(root->right);
	}	
}

//FUNCTION FOR  DESCENDING ORDER
void dict :: descend(node *root)			
{
	cout<<"descending order is\n";
	if(root!=NULL)
	{	
		inorder(root->right);
		cout<<root->word;
		cout<<root->meaning;
		inorder(root->left);
	}	
}	

//FUNCTION TOO DELETE A WORD
void dict :: deletew()			
{
  char key[30];
  node *temp=root;
	 
	 int count=0;
	
	 
	 if(temp==NULL)
	 {
	 	cout<<"\n Empty dictionary";
	 }
	 while(temp!=NULL)
	 {	
	 	
	 	if(strcmp(temp->word,key)==0)
	 	{
	 	   break;
	 	}
	 	else if(strcmp(temp->word,key)==-1)
	 	{	
	 		temp=temp->left;
	 	}
	 	else
	 	{
	 		temp=temp->right;
	 	}
	 	count++;
	
	 }
	 
	if(temp==NULL)
		cout<<"Node not found";
	else
	{
		cout<<"at page"<<count;
		cout<<"meaning:"<<temp->meaning;
            cout<<"node is deleted";
                
                strcpy(temp->meaning,"");
                strcpy(temp->word,"");
                delete temp;
                
                if(temp==root)
                {
                    temp=temp->left;
                    delete temp->left;
                }
                else
                {
                    temp=temp->right;
                    delete temp->right;
                }
	}
   
}	

//FUNCTION TO UPDATE A WORD
void dict::update()
{
	char key[30];
	node *temp;
	cout<<"enter the key to enter\n";
	cin>>key;
	temp=search(key);
	if(temp!=NULL)
	{
		cout<<"enter the new meaning of word\n";
		cin>>temp->meaning;
	}
	else
	cout<<"word not found\n";
}

//MAIN FUNCTION
int main()
{
	dict obj;
	int x,ch,i,n,h;
	char key[50];
	do{
		cout<<"\nEnter your choice \n#1.Insert node \n#2.ascending \n#3.search key \n#4.delete \n#5.descendING \n#6.update \n#7.exit";
		cin>>ch;
		
		switch(ch)
		{	
		
			case 1:
				cout<<"how many word to enter in your dictionary";
				cin>>n;
				for(i=0;i<n;i++)
				obj.insert();
				break;
			case 2:
				cout<<"\nascending order is";
				obj.inorder(obj.root);
				break;
			case 3:
				cout<<"Enter key that u want to search in  tree ";
				cin>>key;
				obj.search(key);
				break;
		    	case 4:
				obj.deletew();
                         	break;
                  	case 5:
				obj.descend(obj.root);
	                  	break;
        	        case 6:
				obj.update();
	                  	break;
			case 7:
				cout<<"\n thankyou";
				break;
			default:
				cout<<"\n wrong choice";
				break;
		}
		
	}while(ch!=7);
	return 0;
}

/*prajktapatil@kkw-HP-Pro-3330-MT:~$ g++ dictionary.cpp
prajktapatil@kkw-HP-Pro-3330-MT:~$ ./a.out

Enter your choice 
#1.Insert node 
#2.ascending 
#3.search key 
#4.delete 
#5.descendING 
#6.update 
#7.exit1
how many word to enter in your dictionary1
enter the word
prajkta
enter the meaning
flower

Enter your choice 
#1.Insert node 
#2.ascending 
#3.search key 
#4.delete 
#5.descendING 
#6.update 
#7.exit1
how many word to enter in your dictionary1
enter the word
radhika
enter the meaning
patience

Enter your choice 
#1.Insert node 
#2.ascending 
#3.search key 
#4.delete 
#5.descendING 
#6.update 
#7.exit3
Enter key that u want to search in  tree prajkta
key found
Enter your choice 
#1.Insert node 
#2.ascending 
#3.search key 
#4.delete 
#5.descendING 
#6.update 
#7.exit2

ascending order isprajktaflowerradhikapatience
Enter your choice 
#1.Insert node 
#2.ascending 
#3.search key 
#4.delete 
#5.descendING 
#6.update 
#7.exit7

 thankyouprajktapatil@kkw-HP-Pro-3330-MT:~$ 
*/
