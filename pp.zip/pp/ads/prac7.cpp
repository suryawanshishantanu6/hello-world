/*

Pr. No: 08

Title : A Dictionary stores keywords & its meanings. Provide facility for adding new keywords, deleting keywords, updating values of any entry. Provide facility to display whole data sorted in ascending/ Descending order. Also find how many maximum comparisons may require for finding any keyword. Use Height balance tree and find the complexity for finding a keyword.

Batch : A, B, C, D

Programmer : Asst. Prof. Samadhan W. Jadhav.

*/


//----------------------Header Files ----------------------------
#include<iostream>
#include<string.h>
using namespace std;


//----------------------Global Variables ----------------------------



//---------------------- Structure for AVLTree Nodes ----------------------------

struct AVLNode
{
	char Keyword[20];
	char Meaning[20];
	int BF;
	struct AVLNode *left,*right;
}*Root;


//---------------------- Class for AVLTree Operations ----------------------------

class AVLTree
{
   public:

        AVLTree()
        {
	   Root = NULL;
	}

	void create();
	void insert(AVLNode *root, AVLNode *Newnode);
	void disp_Inorder(AVLNode *root);
	void search(AVLNode *root, char key[]);		
	void modify(AVLNode *root, char key[]);
	void del_node(AVLNode *root, char key[]);
	
};


//----------------------Definations of Class Member Functions ----------------------------

//---------------------- Create AVLTree's Root ----------------------------

void AVLTree :: create()
{
   if(Root == NULL)
   {
     struct AVLNode *tmp;	// Pointer Declaration

     tmp = new(struct AVLNode);		//DMA

     cout<<"\n\t Enter keyword: "; 	//Data & Address Assignment
     cin>>tmp->Keyword;
     cout<<"\n\t Enter Meaning: "; 	//Data & Address Assignment
     cin>>tmp->Meaning;
     
     tmp->BF = 0;

     tmp->left = NULL;
     tmp->right = NULL;

     Root = tmp;
   }

}


//---------------------- Insert Nodes in AVLTree ----------------------------

void AVLTree :: insert(AVLNode *root, AVLNode *newNode)
{    
     if(strcmp(newNode->Keyword,root->Keyword) < 0)
     {
        if(root->left == NULL)
           root->left = newNode;
        else
           insert(root->left, newNode);
     }
     else
     {
        if(root->right == NULL)
           root->right = newNode;
        else
           insert(root->right, newNode);
     }
     
}


//---------------------- Display AVLTree in Inorder ----------------------------

void AVLTree :: disp_Inorder(AVLNode *root)
{
    if(root != NULL)
    {
       	disp_Inorder(root->left);       
	cout<<"\n "<<root->Keyword;
	cout<<"  "<<root->Meaning;
	cout<<"  "<<root->BF;
	disp_Inorder(root->right);
    }
}


//---------------------- Search Nodes of AVLTree ---------------------

void AVLTree :: search(AVLNode *root, char key[])
{
    
    if(root)
    {
    	if(strcmp(root->Keyword, key) == 0)
    	{	
	   cout<<"\n\n\t Element Found !!!";
	   cout<<"\n -----------------------";
	   cout<<"\n Keyword | Meaning | BF |";
	   cout<<"\n -----------------------";
	   cout<<"\n"<<root->Keyword<<"  "<<root->Meaning<<"  "<<root->BF;
    	}
    	else if(strcmp(key, root->Keyword) < 0)
           search(root->left, key);	
    	else
    	   search(root->right, key);
    }	 

}

//---------------------- Modify Nodes of AVLTree ---------------------
void AVLTree :: modify(AVLNode *root, char key[])
{
    if(root)
    {
    	if(strcmp(root->Keyword, key) == 0)
    	{	
	   cout<<"\n\n\t Keyword Found to modify !!!";
	   cout<<"\n\t Enter New keyword: "; 	
     	   cin>>root->Keyword;
     	   cout<<"\n\t Enter New Meaning: "; 	
     	   cin>>root->Meaning;
    	}
    	else if(strcmp(key, root->Keyword) < 0)
           search(root->left, key);	
    	else
    	   search(root->right, key);
    }	 
}

//---------------------- Delete Nodes of AVLTree ---------------------
void AVLTree :: del_node(AVLNode *root, char key[])
{
   cout<<"\n\n\t *** Are baba pahle Coding to kar :-) ";
}

//---------------------- Main Function ----------------------------

int main()
{
     int i, nodes, ch;

     char ans[2], key[20];

     AVLTree Tree1;

     do
     {
  	cout<<"\n\n ** Menu **";
  	cout<<"\n\n 1. Create AVL Tree";
  	cout<<"\n\n 2. Insert Nodes in AVL Tree";
  	cout<<"\n\n 3. Display AVL Tree as Inorder";
  	cout<<"\n\n 4. Search in AVL Tree";
  	cout<<"\n\n 5. Modify Nodes of AVL Tree";
  	cout<<"\n\n 6. Delete Nodes of AVL Tree";

	cout<<"\n\n Enter your choice: ";
	cin>>ch;

	switch(ch)
	{
	   	case 1: Tree1.create();
			cout<<"\n\t AVL Tree Created !!!";
			break;

		case 2: cout<<"\n\t How many Nodes to insert: ";
     			cin>>nodes;

     			for(i=0; i<nodes; i++)
     			{
     			  struct AVLNode *newNode;
       			  newNode = new(struct AVLNode);		//DMA

		          cout<<"\n\t Enter keyword: "; 	//Data & Address Assignment
     			  cin>>newNode->Keyword;
     			  cout<<"\n\t Enter Meaning: "; 	
     			  cin>>newNode->Meaning;

			  newNode->BF = 0;
		          newNode->left = NULL;
		          newNode->right = NULL;

		          Tree1.insert(Root,newNode);
     			}
			cout<<"\n\t Nodes inserted in AVL Tree !!!";
		 	break;

		case 3: cout<<"\n\n\t AVL Tree (Inorder)";
			cout<<"\n -----------------------";
			cout<<"\n Keyword | Meaning | BF |";
			cout<<"\n -----------------------";
			Tree1.disp_Inorder(Root);
			break;

		case 4: cout<<"\n\n\t Enter the Keyword to Search: ";
         		cin>>key;
         		Tree1.search(Root, key);	               
     			break;

		case 5: cout<<"\n\n\t Enter the Keyword to Modify: ";
         		cin>>key;
         		Tree1.modify(Root, key);	               
     			break;

		case 6: cout<<"\n\n\t Enter the Keyword to Delete: ";
         		cin>>key;
         		Tree1.del_node(Root, key);	               
     			break;

		default: cout<<"\n\n\t Wrong Choice !!!";

	}

	cout<<"\n\n\t Do u wanna continue: ";
	cin>>ans;
	
     }while(strcmp(ans,"n") != 0);

     cout<<"\n\n";
     return 0;
}


/*
-----------------------------Output-----------------------------------

student@CORELAB1:~$ g++ Pr_8ABCD.cpp -o a
student@CORELAB1:~$ ./a


 ** Menu **

 1. Create AVL Tree

 2. Insert Nodes in AVL Tree

 3. Display AVL Tree as Inorder

 4. Search in AVL Tree

 5. Modify Nodes of AVL Tree

 6. Delete Nodes of AVL Tree

 Enter your choice: 1

	 Enter keyword: Curious

	 Enter Meaning: Eager

	 AVL Tree Created !!!

	 Do u wanna continue: y


 ** Menu **

 1. Create AVL Tree

 2. Insert Nodes in AVL Tree

 3. Display AVL Tree as Inorder

 4. Search in AVL Tree

 5. Modify Nodes of AVL Tree

 6. Delete Nodes of AVL Tree

 Enter your choice: 2

	 How many Nodes to insert: 2

	 Enter keyword: Satisfactory

	 Enter Meaning: Acceptable

	 Enter keyword: Attitude

	 Enter Meaning: Feelings

	 Nodes inserted in AVL Tree !!!

	 Do u wanna continue: y


 ** Menu **

 1. Create AVL Tree

 2. Insert Nodes in AVL Tree

 3. Display AVL Tree as Inorder

 4. Search in AVL Tree

 5. Modify Nodes of AVL Tree

 6. Delete Nodes of AVL Tree

 Enter your choice: 3


	 AVL Tree (Inorder)
 ------------------------------
 Keyword    | Meaning    | BF |
 ------------------------------
 Attitude     Feelings     0
 Curious      Eager        0
 Satisfactory Acceptable   0

	 Do u wanna continue: y


 ** Menu **

 1. Create AVL Tree

 2. Insert Nodes in AVL Tree

 3. Display AVL Tree as Inorder

 4. Search in AVL Tree

 5. Modify Nodes of AVL Tree

 6. Delete Nodes of AVL Tree

 Enter your choice: 4


	 Enter the Keyword to Search: Attitude


	 Element Found !!!
 -----------------------
 Keyword | Meaning | BF |
 -----------------------
Attitude   Feelings   0

	 Do u wanna continue: y


 ** Menu **

 1. Create AVL Tree

 2. Insert Nodes in AVL Tree

 3. Display AVL Tree as Inorder

 4. Search in AVL Tree

 5. Modify Nodes of AVL Tree

 6. Delete Nodes of AVL Tree

 Enter your choice: 5


	 Enter the Keyword to Modify: Curious


	 Keyword Found to modify !!!
	 Enter New keyword: Culture

	 Enter New Meaning: Values


	 Do u wanna continue: y


 ** Menu **

 1. Create AVL Tree

 2. Insert Nodes in AVL Tree

 3. Display AVL Tree as Inorder

 4. Search in AVL Tree

 5. Modify Nodes of AVL Tree

 6. Delete Nodes of AVL Tree

 Enter your choice: 3


	 AVL Tree (Inorder)
 ------------------------------
 Keyword     | Meaning   | BF |
 ------------------------------
 Attitude      Feelings    0
 Culture       Values      0
 Satisfactory  Acceptable  0

	 Do u wanna continue: y


 ** Menu **

 1. Create AVL Tree

 2. Insert Nodes in AVL Tree

 3. Display AVL Tree as Inorder

 4. Search in AVL Tree

 5. Modify Nodes of AVL Tree

 6. Delete Nodes of AVL Tree

 Enter your choice: 6


	 Enter the Keyword to Delete: Satisfactory


	 *** Are baba pahle Coding to kar :-) 

	 Do u wanna continue: n


student@CORELAB1:~$ 

----------------------------------------------------------------------*/
