/*
Pr. No: 07
Title : Given sequence k = k1 <k2 < … < kn of n sorted keys, with a search probability pi for each key ki . Build the Binary search tree that 		has the least search cost given the access probability for each key. 
Batch : A & D
Programmer: Asst. Prof. S.W.Jadhav.
*/

//----------------------Header Files ----------------------------
#include<iostream>
using namespace std;


//----------------------Global Variables ----------------------------

float Probability = 0.1;
int Level = 1;

//---------------------- Structure for BST Nodes ----------------------------
struct BSTNode
{
	int data;
	struct BSTNode *left,*right;
}*Root;


//---------------------- Class for BST Operations ----------------------------
class BST
{
   public:
        BST()
        {
	   Root = NULL;
	}
	void create();
	void insert(BSTNode *root, BSTNode *Newnode);
	void disp_Inorder(BSTNode *root);
	float search(BSTNode *root, int key);		
};


//----------------------Definations of Class Member Functions ----------------------------

//---------------------- Create BST's Root ----------------------------

void BST :: create()
{
   if(Root == NULL)
   {
     struct BSTNode *tmp;
     tmp = new(struct BSTNode);
     cout<<"\n\t Enter data for Root: ";
     cin>>tmp->data;
     tmp->left = NULL;
     tmp->right = NULL;

     Root = tmp;
   }

}


//---------------------- Insert Nodes in BST ----------------------------

void BST :: insert(BSTNode *root, BSTNode *newNode)
{    
     if(newNode->data < root->data)
     {
        if(root->left == NULL)
           root->left = newNode;
        else
           insert(root->left, newNode);
     }
     else
     {
        if(root->right == NULL)
           root->right = newNode;
        else
           insert(root->right, newNode);
     }
     
}


//---------------------- Display BST in Inorder ----------------------------

void BST :: disp_Inorder(BSTNode *root)
{
    if(root != NULL)
    {
       	disp_Inorder(root->left);       
	cout<<"  "<<root->data;
	disp_Inorder(root->right);
    }
}


//---------------------- Search Nodes of BST to find Access Probability---------------------

float search(BSTNode *root, int key)
{
    float A_Pro = 0.0;
    if(root)
    {
    	if(root->data == key)
    	{	
	   cout<<"\n\t Item \t Level \t Probability \t Access Time/Pro";
	   cout<<"\n\t"<<root->data;
	   cout<<"\t "<<Level;
	   cout<<"\t "<<Probability;
	   A_Pro = Level * Probability;
	   cout<<"\t\t "<<A_Pro;
	   Level = Level + 1;
	   Probability = Probability + 0.1;
	   return A_Pro;
    	}
    	else if(key < root->data)
           search(root->left, key);	
    	else
    	   search(root->right, key);
    }	
 
}


//---------------------- Main Function ----------------------------

int main()
{
     int i, nodes, key, ch;

     char ans;

     float total_Pro = 0.0;

     BST Tree1;

     do
     {
  	cout<<"\n\n ** Menu **";
  	cout<<"\n\n 1. Create BST";
  	cout<<"\n\n 2. Insert Nodes in BST";
  	cout<<"\n\n 3. Display BST as Inorder";
  	cout<<"\n\n 4. Search in BST";
  	cout<<"\n\n 5. Exit";

	cout<<"\n\n Enter your choice: ";
	cin>>ch;

	switch(ch)
	{
	   	case 1: Tree1.create();
			cout<<"\n\t BST Created !!!";
			break;

		case 2: cout<<"\n\t How many Nodes to insert: ";
     			cin>>nodes;

     			for(i=0; i<nodes; i++)
     			{
     			  struct BSTNode *newNode;
       			  newNode = new(struct BSTNode);

		          cout<<"\n\t Enter data for New Node: ";
		          cin>>newNode->data;
		          newNode->left = NULL;
		          newNode->right = NULL;

		          Tree1.insert(Root,newNode);
     			}
			cout<<"\n\t Nodes inserted in BST !!!";
		 	break;

		case 3: cout<<"\n\n\t Binary Search Tree (Inorder)";
			Tree1.disp_Inorder(Root);
			break;

		case 4: cout<<"\n\n\t To find Access Probability";
			cout<<"\n\n\t Search each node in BST";
			for(i=0; i<nodes+1; i++)
     			{
	 		   cout<<"\n\n\t Enter the Key to Search: ";
         		   cin>>key;
         		   total_Pro = total_Pro + search(Root, key);	               
     			}

     			cout<<"\n\n\t Total Access Probability: "<<total_Pro;
			break;

		default: cout<<"\n\n\t Wrong Choice !!!";

	}

	cout<<"\n\n\t Do u wanna continue: ";
	cin>>ans;
	
     }while(ans != 'n');

     cout<<"\n\n";
     return 0;
}

/*
-----------------------------Output-----------------------------------
student@CORELAB1:~$ g++ Pr_7AD.cpp -o a
student@CORELAB1:~$ ./a


 ** Menu **

 1. Create BST

 2. Insert Nodes in BST

 3. Display BST as Inorder

 4. Search in BST

 5. Exit

 Enter your choice: 1

	 Enter data for Root: 11

	 BST Created !!!

	 Do u wanna continue: y


 ** Menu **

 1. Create BST

 2. Insert Nodes in BST

 3. Display BST as Inorder

 4. Search in BST

 5. Exit

 Enter your choice: 2

	 How many Nodes to insert: 2

	 Enter data for New Node: 22

	 Enter data for New Node: 33

	 Nodes inserted in BST !!!

	 Do u wanna continue: y


 ** Menu **

 1. Create BST

 2. Insert Nodes in BST

 3. Display BST as Inorder

 4. Search in BST

 5. Exit

 Enter your choice: 3


	 Binary Search Tree (Inorder)  11  22  33

	 Do u wanna continue: y


 ** Menu **

 1. Create BST

 2. Insert Nodes in BST

 3. Display BST as Inorder

 4. Search in BST

 5. Exit

 Enter your choice: 4


	 To find Access Probability

	 Search each node in BST

	 Enter the Key to Search: 11

	 Item 	 Level 	 Probability 	 Access Time/Pro
	11	 1	 0.1		 0.1

	 Enter the Key to Search: 22

	 Item 	 Level 	 Probability 	 Access Time/Pro
	22	 2	 0.2		 0.4

	 Enter the Key to Search: 33

	 Item 	 Level 	 Probability 	 Access Time/Pro
	33	 3	 0.3		 0.9

	 Total Access Probability: 1.4

	 Do u wanna continue: y


 ** Menu **

 1. Create BST

 2. Insert Nodes in BST

 3. Display BST as Inorder

 4. Search in BST

 5. Exit

 Enter your choice: 5


	 Wrong Choice !!!

	 Do u wanna continue: n


student@CORELAB1:~$

*/
